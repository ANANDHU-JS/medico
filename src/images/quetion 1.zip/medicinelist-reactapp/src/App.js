import './App.css'; 
import { useNavigate } from 'react-router-dom';

function App() {
  const navigate = useNavigate();

  function gotoRegister() {
    navigate('register');
  }

  function gotoLogin() {
    navigate('login');
  }

  return (
    <div className="background">
      <div className="heading text-center">
        <h1 className="mb-4">Medicine List App</h1>
        
        <button className="btn btn-warning mt-3" onClick={gotoRegister}>Register</button>
        <button className="btn btn-warning mt-3 ml-3" onClick={gotoLogin}>Login</button>
      </div>
    </div>
  );
}

export default App;
